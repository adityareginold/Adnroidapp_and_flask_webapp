package com.example.admissionmanage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class AddReview extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText e1;
    RatingBar r;
    Button b;
    Spinner sp;
    String review, ip = "", stid,rate;
    SharedPreferences sh;
    ArrayList<String> staff, staffid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_review);
        r = (RatingBar) findViewById(R.id.ratingBar);
        sp = (Spinner) findViewById(R.id.spinner3);
        e1 = (EditText) findViewById(R.id.editTextTextPersonName2);
        b = (Button) findViewById(R.id.button6);
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip = sh.getString("ipaddress", "");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                review=e1.getText().toString();
                rate=r.getRating()+"";

                RequestQueue queue = Volley.newRequestQueue(AddReview.this);
                String url ="http://"+ip+":5000/rating";

                // Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the response string.
                        Log.d("+++++++++++++++++",response);
                        try {
                            JSONObject json=new JSONObject(response);
                            String res=json.getString("task");
                            if(res.equals("fail"))
                            {
                                Toast.makeText(getApplicationContext(),"invalid user",Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_LONG).show();
                                Intent i=new Intent(getApplicationContext(),Studenthome.class);
                                startActivity(i);


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {


                                Toast.makeText(getApplicationContext(),"Error"+error,Toast.LENGTH_LONG).show();
                            }
                        }){
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<String, String>();
                        params.put("staffid",stid);
                        params.put("stid",sh.getString("studentid",""));
                        params.put("ratings",rate);
                        params.put("review",review);

                        return params;
                    }
                };
                // Add the request to the RequestQueue.
                queue.add(stringRequest);
            }
        });
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(AddReview.this);
        String url = "http://" + ip + ":5000/viewstaff";

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {

                    JSONArray ar = new JSONArray(response);

                    staffid = new ArrayList<>();
                    staff = new ArrayList<>();
                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        staffid.add(jo.getString("login_id"));
                        staff.add(jo.getString("first_name") + " " + jo.getString("middle_name") + " " + jo.getString("last_name"));
                    }

                    ArrayAdapter<String> ad;
                    ad = new ArrayAdapter<>(getApplication(), android.R.layout.simple_list_item_1, staff);
                    sp.setAdapter(ad);
                    sp.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) AddReview.this);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                return params;
            }
        };
        // Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        stid=staffid.get(position);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}