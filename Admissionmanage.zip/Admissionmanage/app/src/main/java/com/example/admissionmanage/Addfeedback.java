 package com.example.admissionmanage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Addfeedback extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText e2;
    Button b;
    String feedback,ip=" ",stid;
    Spinner sp;
    SharedPreferences sh;
    ArrayList<String> student,studentid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addfeedback);
        sp=(Spinner)findViewById(R.id.spinner);
        e2=(EditText)findViewById(R.id.editTextTextMultiLine2);
        b=(Button)findViewById(R.id.button9);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip=sh.getString("ipaddress","");
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(Addfeedback.this);

        String url ="http://"+ip+":5000/viewstudent";

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++",response);
                try {

                    JSONArray ar=new JSONArray(response);

                    studentid=new ArrayList<>();
                    student=new ArrayList<>();
                    for(int i=0;i<ar.length();i++)
                    {
                        JSONObject jo=ar.getJSONObject(i);
                        studentid.add(jo.getString("login_id"));
                        student.add(jo.getString("first_name")+" " +jo.getString("middle_name")+" "+jo.getString("last_name"));
                    }
                    //  lv.setAdapter(new Custom(Viewfeedback.this,feedb,date,staff));
                    ArrayAdapter<String> ad=new ArrayAdapter<>(getApplication(), android.R.layout.simple_list_item_1,student);
                    sp.setAdapter(ad);
                    sp.setOnItemSelectedListener(Addfeedback.this);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(),"Error"+error,Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();



                return params;
            }
        };
        // Add the request to the RequestQueue.
        queue.add(stringRequest);

//        RequestQueue queue = Volley.newRequestQueue(Addfeedback.this);
//        String url ="http://"+ip+":5000/feedback";
//
//        // Request a string response from the provided URL.
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                // Display the response string.
//                Log.d("+++++++++++++++++",response);
//                try {
//                    JSONObject json=new JSONObject(response);
//                    String res=json.getString("result");
//
//                    if(res.equalsIgnoreCase("error"))
//                    {
//                        Toast.makeText(getApplicationContext(),res,Toast.LENGTH_LONG).show();
//                    }
//                    else
//                    {
//                        startActivity(new Intent(getApplicationContext(),Viewfeedback.class));
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
//            }
//        }){
//            @Override
//            protected Map<String, String> getParams()
//            {
//                Map<String, String>  params = new HashMap<String, String>();
//                params.put("stid", sh.getString("staffid",""));
//                params.put("feedback", feedback);
//
//                return params;
//            }
//        };
//        // Add the request to the RequestQueue.
//        queue.add(stringRequest);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                feedback = e2.getText().toString();
                if (feedback.equalsIgnoreCase("")) {
                    e2.setError("Enter Password");
                }

                else {
                    RequestQueue queue = Volley.newRequestQueue(Addfeedback.this);
                    String url = "http://" + ip + ":5000/feedback";

                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Display the response string.
                            Log.d("+++++++++++++++++", response);
                            try {
                                JSONObject json = new JSONObject(response);
                                String res = json.getString("task");
                                if (res.equals("fail")) {
                                    Toast.makeText(getApplicationContext(), "invalid user", Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_LONG).show();
                                    Intent i = new Intent(getApplicationContext(), Teacherhome.class);
                                    startActivity(i);


                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {


                                    Toast.makeText(getApplicationContext(), "Error" + error, Toast.LENGTH_LONG).show();
                                }
                            }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("sid", stid);
                            params.put("staffid", sh.getString("staffid", ""));

                            params.put("feedback", feedback);

                            return params;
                        }
                    };
                    // Add the request to the RequestQueue.
                    queue.add(stringRequest);
                }
            }
        });
    }






    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        stid=studentid.get(position);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}