 package com.example.admissionmanage;

 import android.content.Intent;
 import android.content.SharedPreferences;
 import android.preference.PreferenceManager;

 import android.os.Bundle;
 import android.util.Log;
 import android.util.Patterns;
 import android.view.View;
 import android.widget.ArrayAdapter;
 import android.widget.Button;
 import android.widget.EditText;
 import android.widget.RadioButton;
 import android.widget.TextView;
 import android.widget.Toast;

 import com.android.volley.Request;
 import com.android.volley.RequestQueue;
 import com.android.volley.Response;
 import com.android.volley.VolleyError;
 import com.android.volley.toolbox.StringRequest;
 import com.android.volley.toolbox.Volley;

 import org.json.JSONException;
 import org.json.JSONObject;

 import java.util.HashMap;
 import java.util.Map;
import android.widget.Spinner;

 import androidx.appcompat.app.AppCompatActivity;

 public class registration extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e6,e7,e8,e9,e10,e11;
    RadioButton r1,r2,r3;
    Button b1;
    String type[]={"Student","Staff"};
    String fname,mname,lname,age,address,email,phone,qualification, interestofstdytea,gender,ip=" ",un,pwd,types;
    Spinner s1;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        e1=(EditText)findViewById(R.id.editTextTextPersonName3);
        e2=(EditText)findViewById(R.id.editTextTextPersonName4);
        e3=(EditText)findViewById(R.id.editTextTextPersonName5);
        e4=(EditText) findViewById(R.id.editTextTextPersonName6);
        e5=(EditText)findViewById(R.id.editTextTextMultiLine);
        e6=(EditText)findViewById(R.id.editTextTextEmailAddress);
        e7=(EditText)findViewById(R.id.editTextPhone);
        e8=(EditText)findViewById(R.id.editTextTextPersonName7);
        e9=(EditText)findViewById(R.id.editTextTextPersonName8);
        e10=(EditText)findViewById(R.id.editTextTextPersonName10);
        e11=(EditText)findViewById(R.id.editTextTextPassword2);
        r1=(RadioButton)findViewById(R.id.radioButton);
        r2=(RadioButton)findViewById(R.id.radioButton6);
        r3=(RadioButton)findViewById(R.id.radioButton2);
        s1=(Spinner)findViewById(R.id.spinner2);

        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip=sh.getString("ipaddress","");
        b1=(Button)findViewById(R.id.button2);
        ArrayAdapter<String> ad=new ArrayAdapter<>(registration.this,android.R.layout.simple_list_item_1,type);
        s1.setAdapter(ad);
         b1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 fname= e1.getText().toString();
                 mname= e2.getText().toString();
                 lname= e3.getText().toString();
                 if(r1.isChecked())
                 {
                     gender=r1.getText().toString();
                 }
                 else if(r2.isChecked())
                 {
                     gender=r2.getText().toString();
                 }
                 else {
                     gender=r3.getText().toString();
                 }
                 age= e4.getText().toString();
                 address= e5.getText().toString();
                 email= e6.getText().toString();
                 phone= e7.getText().toString();
                 qualification=e8.getText().toString();
                 interestofstdytea=e9.getText().toString();
                 un=e10.getText().toString();
                 pwd=e11.getText().toString();
                 types=s1.getSelectedItem().toString();
                 Toast.makeText(getApplicationContext(),types,Toast.LENGTH_LONG).show();
                 if(fname.equalsIgnoreCase(""))
                 {
                     e1.setError("Enter Your First Name");
                 }
                 else if(!fname.matches("^[a-z A-Z]*$"))
                 {
                     e1.setError("characters allowed");
                 }
                 else if(lname.equalsIgnoreCase(""))
                 {
                     e3.setError("Enter Your Last name");
                 }
                 else if(!lname.matches("^[a-z A-Z]*$"))
                 {
                     e3.setError("characters allowed");
                 }
                 else if(age.length()>2)
                 {
                     e4.setError("Enter valid age" +
                             "");
                     e4.requestFocus();
                 }
                 else if(address.equalsIgnoreCase(""))
                 {
                     e5.setError("Enter Your address");
                 }
                 else if(email.equalsIgnoreCase(""))
                 {
                     e6.setError("Enter Your Email");
                 }
                 else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
                 {
                     e6.setError("Enter Valid Email");
                     e6.requestFocus();
                 }
                 else if(phone.equalsIgnoreCase(""))
                 {
                     e7.setError("Enter Your Phone No");
                 }
                 else if(phone.length()!=10)
                 {
                     e7.setError("Minimum 10 nos required");
                     e7.requestFocus();
                 }
                 else if(qualification.equalsIgnoreCase(""))
                 {
                     e8.setError("Enter Your Qualification");
                 }
                 else if(interestofstdytea.equalsIgnoreCase(""))
                 {
                     e9.setError("Enter Your interest");
                 }
                 else if(un.equalsIgnoreCase(""))
                 {
                     e10.setError("Enter Username");
                 }
                 else if(pwd.equalsIgnoreCase(""))
                 {
                     e11.setError("Enter Password");
                 }
                 else if(pwd.length()<6)
                 {
                     e11.setError("Type Valid Password");
                     e11.requestFocus();
                 }





                 else
                 {
                     RequestQueue queue = Volley.newRequestQueue(registration.this);
                     String url = "http://" + ip + ":5000/signup";

                     // Request a string response from the provided URL.
                     StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                         @Override
                         public void onResponse(String response) {
                             // Display the response string.
                             Log.d("+++++++++++++++++", response);
                             try {
                                 JSONObject json = new JSONObject(response);
                                 String res = json.getString("task");
                                 Toast.makeText(getApplicationContext(), res, Toast.LENGTH_LONG).show();
                                 if(res.equals("success"))
                                 startActivity(new Intent(getApplicationContext(), Login.class));
                             } catch (JSONException e) {
                                 e.printStackTrace();
                             }


                         }
                     }, new Response.ErrorListener() {
                         @Override
                         public void onErrorResponse(VolleyError error) {

                             Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                         }
                     }) {
                         @Override
                         protected Map<String, String> getParams() {
                             Map<String, String> params = new HashMap<String, String>();
                             params.put("FName", fname);
                             params.put("MName", mname);
                             params.put("LName", lname);
                             params.put("Age", age);
                             params.put("Address", address);

                             params.put("Gender", gender);
                             params.put("Email", email);
                             params.put("Phone", phone);
                             params.put("Qualification", qualification);
                             params.put("InterestedArea", interestofstdytea);
                             params.put("un", un);
                             params.put("pw", pwd);
                             params.put("type", types);

                             return params;
                         }
                     };
                     // Add the request to the RequestQueue.
                     queue.add(stringRequest);

                 }

             }
         });



    }
}