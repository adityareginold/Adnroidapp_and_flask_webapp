package com.example.admissionmanage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class staffchatlist extends AppCompatActivity implements AdapterView.OnItemClickListener {
    SharedPreferences sh;
    ListView lv;
    ArrayList<String> name,id;
    String url,ip;
    int pos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staffchatlist);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        lv = (ListView) findViewById(R.id.list4);




        ip = sh.getString("ipaddress", "");


        url = "http://" + ip + ":5000/viewstaff";


        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(staffchatlist.this);


        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                // Display the response string.
                Log.d("+++++++++++++++++", response);
                try {

                    JSONArray ar = new JSONArray(response);

                    name = new ArrayList<>();
                    id = new ArrayList<>();


                    for (int i = 0; i < ar.length(); i++) {
                        JSONObject jo = ar.getJSONObject(i);
                        name.add(jo.getString("first_name") + " " + jo.getString("middle_name") + " " + jo.getString("last_name"));
                        id.add(jo.getString("login_id"));
//                        Toast.makeText(getApplicationContext(),jo.getString("first_name"),Toast.LENGTH_LONG).show();
                    }
                    ArrayAdapter<String> ad = new ArrayAdapter<>(staffchatlist.this, android.R.layout.simple_list_item_1, name);
                    lv.setAdapter(ad);
                    lv.setOnItemClickListener(staffchatlist.this);
                    //  lv.setAdapter(new Custom2(Chatlist.this,name));
                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "error " + e, Toast.LENGTH_LONG).show();

                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), "Error" + error, Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                //  params.put("sffid", sh.getString("staffid","1"));


                return params;
            }
        };
        // Add the request to the RequestQueue.
        queue.add(stringRequest);



    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long l) {

        pos=i;
        Intent in=new Intent(getApplicationContext(),staffchat.class);


//        in.putExtra("sid",""+id);
//        in.putExtra("name",""+name);

        in.putExtra("sid", id.get(pos));
        in.putExtra("name", name.get(pos));


        startActivity(in);







    }
}