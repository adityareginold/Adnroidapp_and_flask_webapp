package com.example.admissionmanage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class Login extends AppCompatActivity {


    EditText e1,e2;
    Button b1,b2,b;
    String username,password;
    SharedPreferences sh;
    String ip="";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        e1=(EditText)findViewById(R.id.editTextTextPersonName9);
        e2=(EditText)findViewById(R.id.editTextTextPassword);
        b1=(Button)findViewById(R.id.button5);
        b2=(Button)findViewById(R.id.button7);
        b=(Button)findViewById(R.id.button90);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip=sh.getString("ipaddress","");


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username=e1.getText().toString();
                password=e2.getText().toString();
//                Toast.makeText(getApplicationContext(),"WELCOME"+username,Toast.LENGTH_LONG).show();
                // Instantiate the RequestQueue.
                RequestQueue queue = Volley.newRequestQueue(Login.this);
                String url ="http://"+ip+":5000/login";

                // Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the response string.
                        Log.d("+++++++++++++++++",response);
                        try {
                            JSONObject json=new JSONObject(response);
                            String res=json.getString("task");
                            if(res.equals("fail"))
                            {
                                Toast.makeText(getApplicationContext(),"invalid user",Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                            String arr[]=res.split("#");
                            String id=arr[0];

                            String type=arr[1];

                            if(type.equals("student"))
                            {

                                SharedPreferences.Editor ed2=sh.edit();
                                ed2.putString("studentid",id);
                                ed2.commit();
                                startActivity(new Intent(getApplicationContext(),Studenthome.class));


                            }
                            else if(type.equals("staff"))
                            {
                                SharedPreferences.Editor ed1=sh.edit();
                                ed1.putString("staffid",id);
                                ed1.commit();
                                startActivity(new Intent(getApplicationContext(),Teacherhome.class));

                            }
                            else
                                {
                                Toast.makeText(getApplicationContext(),"Invalid user",Toast.LENGTH_LONG).show();
                                }}
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                        Toast.makeText(getApplicationContext(),"Error"+error,Toast.LENGTH_LONG).show();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<String, String>();
                        params.put("un", username);
                        params.put("ps", password);

                        return params;
                    }
                };
                // Add the request to the RequestQueue.
                queue.add(stringRequest);
                    }
                });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
                    public void onClick(View view) {
                        Intent i=new Intent(getApplicationContext(),registration.class);
                        startActivity(i);
                    }
                });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
                public void onClick(View view) {
                    Intent i=new Intent(getApplicationContext(), Publichome.class);
                    startActivity(i);
            }
        });


            }
        }


