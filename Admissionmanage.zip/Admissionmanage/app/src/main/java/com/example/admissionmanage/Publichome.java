package com.example.admissionmanage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;

public class Publichome extends AppCompatActivity {
  Button b1,b2,b3;
  SharedPreferences sh;
  String ip=" ";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publichome);
        b1=(Button)findViewById(R.id.button28);
        b2=(Button)findViewById(R.id.button29);
       // b3=(Button)findViewById(R.id.button30);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip=sh.getString("ipaddress","");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),Viewfeeds.class);
                startActivity(i);
            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),Viewteacher.class);
                startActivity(i);
            }
        });


       // b3.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //    public void onClick(View view) {
        //        Intent i=new Intent(getApplicationContext(),Publicviewrating.class);
         //       startActivity(i);
        //    }
       // });

    }

}