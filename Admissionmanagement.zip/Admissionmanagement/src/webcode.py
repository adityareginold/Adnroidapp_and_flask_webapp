from flask import *
from src .dbop import select,selectall,iud

app=Flask(__name__)
app.secret_key='abc'
@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['post'])
def login():
    uname = request.form['un']
    passwd = request.form['pwd']

    qry="SELECT * FROM login WHERE username='"+uname+"' AND PASSWORD='"+passwd+"'"
    print(qry)
    res=select(qry)
    print(res)
    if res is None:
        return '''<script>alert('Invalid username or password');window.location='/'</script>'''
    else:
        if res[3]=='admin':
            return render_template('adminhome.html')
        else:
            return '''<script>alert('Invalid username or password');window.location='/'</script>'''

@app.route('/viewstudent')
def viewstudent():
    qry="SELECT * FROM student_registration"
    res=selectall(qry)
    print("===============")
    print(res)
    return render_template('viewstudent.html',val=res)

@app.route('/viewstaff')
def viewstaff():
    qry = "SELECT staff_registration.* FROM staff_registration JOIN `login` ON `staff_registration`.`login_id`=`login`.`login_id` WHERE `login`.`type`='pending'"
    res = selectall(qry)
    print("===============")
    print(res)
    return render_template('viewstaff.html',val=res)

@app.route('/viewrating')
def viewrating():
    qry = "SELECT rating.* , staff_registration.first_name, staff_registration.phone_no,staff_registration.email, AVG(rating.ratings) FROM rating JOIN staff_registration ON rating.staff_id=staff_registration.login_id GROUP BY rating.staff_id "
    res = selectall(qry)
    print("===============")
    print(res)
    return render_template('viewrating.html', val=res)

@app.route('/complaint')
def complaint():
    qry="SELECT complaint.* , student_registration.first_name ,`staff_registration`.`first_name` FROM complaint JOIN student_registration ON complaint.student_id=student_registration.login_id JOIN `staff_registration` ON `staff_registration`.`login_id`=`complaint`.`staff_id`WHERE complaint.reply='pending'"
    res=selectall(qry)
    return render_template('complaint.html',val=res)

@app.route('/editstudent')
def editstudent():
    sid = request.args.get('sid')
    session['sid']=sid
    qry="select * from student_registration where student_id='"+str(sid)+"'"
    res=select(qry)
    return render_template('editstudent.html',val=res)

@app.route('/updatecourse',methods=['post'])
def updatecourse():
    sid = session['sid']
    course = request.form['course']
    qry="update student_registration set interest_area='" +course+ "' where student_id ='"+str(sid)+"'"
    iud(qry)
    return '''<script>alert('success');window.location='/viewstudent'</script>'''

@app.route('/reject')
def reject():
    user_id = request.args.get('uid')
    qry = "DELETE FROM staff_registration WHERE login_id="+str(user_id)+""
    iud(qry)
    qry = "DELETE FROM login WHERE login_id=" + str(user_id) + ""
    iud(qry)
    return '''<script>alert('rejected');window.location='/viewstaff'</script>'''

@app.route('/accept')
def accept():
    user_id = request.args.get('uid')
    qry = "update login set type='staff' WHERE login_id=" + str(user_id) + ""
    iud(qry)
    return '''<script>alert('accepted');window.location='/viewstaff'</script>'''

@app.route('/replycomplaint')
def replycomplaint():
    c_id = request.args.get('cid')
    qry = "SELECT complaint.* , student_registration.first_name FROM complaint JOIN student_registration ON complaint.student_id=student_registration.login_id WHERE complaint.complaint_id='"+str(c_id)+"'"
    res=select(qry)
    return render_template('replycomplaint.html', val=res)

@app.route('/addreply' , methods=['post'])
def addreply():
    c_id= request.form['cid']
    reply= request.form['reply']
    qry= "update complaint set reply='" +reply+ "' where complaint_id ='"+str(c_id)+"'"
    iud(qry)
    return '''<script>window.location='/complaint'</script>'''

@app.route('/viewrating1')
def viewrating1():
    sid= request.args.get('sid')
    qry="SELECT rating.* ,student_registration.first_name, student_registration.phone_no,student_registration.email FROM rating JOIN student_registration ON rating.student_id=student_registration.login_id WHERE rating.staff_id="+str(sid)+""
    res=selectall(qry)
    return render_template('viewrating1.html', val=res)


app.run(debug=True)