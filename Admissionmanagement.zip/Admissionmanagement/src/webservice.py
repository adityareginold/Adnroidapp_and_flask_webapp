import pymysql
from werkzeug.utils import secure_filename

con=pymysql.connect(host='localhost',port=3306,user='root',password='',db='admissionmanage')
cmd=con.cursor()
from flask import Flask,render_template,request,session,make_response,jsonify
from datetime import datetime

app=Flask(__name__)
@app.route('/login',methods=['get','post'])
def log():
    con = pymysql.connect(host='localhost', port=3306, user='root', password='', db='admissionmanage')
    cmd = con.cursor()
    name=request.form['un']
    pword=request.form['ps']
    cmd.execute("select * from login where username='"+str(name)+"' and password='"+str(pword)+"' and type!='admin'")
    s=cmd.fetchone()

    if s==None:
        return jsonify({'task':'fail'})
    else:
        id = str(s[0])
        type = s[3]
        return jsonify({'task':id+"#"+type})

@app.route('/signup',methods=['post','get'])
def signup():
    try:
        fname = request.form['FName']
        print(fname)
        mname = request.form['MName']
        lname = request.form['LName']
        address = request.form['Address']
        email = request.form['Email']
        phone = request.form['Phone']
        print(phone)
        age = request.form['Age']
        gender = request.form['Gender']
        qualification = request.form['Qualification']
        interestedarea = request.form['InterestedArea']
        un = request.form['un']
        pwd = request.form['pw']
        type = request.form['type']
        print(type)

        cmd.execute("insert into login values(NULL,'"+un+"','"+pwd+"','pending')")
        id = con.insert_id()
        if(type=="Student"):

            cmd.execute("insert into student_registration values(null,'"+str(id)+"','"+fname+"','"+mname+"','"+lname+"','"+address+"','"+email+"','"+phone+"','"+age+"','"+gender+"','"+qualification+"','"+interestedarea+"' )")
            con.commit()

            return jsonify({'task':"success"})
        else:
            cmd.execute("insert into staff_registration values(null,'" + str(id) + "','" + fname + "','" + mname + "','" + lname + "','" + address + "','" + email + "','" + phone + "','" + age + "','" + gender + "','" + qualification + "','" + interestedarea + "' )")
            con.commit()
            return jsonify({'task': "success"})

    except Exception as e:
        print(str(e))
        return jsonify({'task': "Username already exists"})


# @app.route('/signup1', methods=['post', 'get'])
# def signup1():
#         try:
#             fname = request.form['FName']
#             mname = request.form['MName']
#             lname = request.form['LName']
#
#             address = request.form['Address']
#             email = request.form['Email']
#             phone = request.form['Phone']
#             age = request.form['Age']
#             gender = request.form['Gender']
#             qualification = request.form['Qualification']
#             interestedarea = request.form['InterestedArea']
#             un = request.form['un']
#             pwd = request.form['pw']
#             cmd.execute("insert into login values(NULL,'" + un + "','" + pwd + "','pending')")
#             id = con.insert_id()

#         except Exception as e:
#             print(str(e))
#             return jsonify({'task': "Fail"})

@app.route('/approve_stud',methods=['POST'])
def approve_stud():
    sid=request.form['sid']
    cmd.execute("SELECT student_registration.* FROM student_registration JOIN `request` ON `request`.`student_id`=`student_registration`.`login_id` WHERE `request`.`status`='pending' AND `request`.`staff_id`="+str(sid)+"")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)

@app.route('/approve_stud1',methods=['POST'])
def approve_stud1():
    try:
        rid=request.form['sid']
        cmd.execute("UPDATE `login` SET `type`='student' WHERE `login_id`="+str(rid)+"")
        con.commit()
        return jsonify({'task':"Success"})
    except Exception as e:
        print(str(e))
        return jsonify({'task':"Fail"})

@app.route('/viewrating',methods=['POST'])
def viewrating():
    cmd.execute("SELECT rating.* , student_registration.first_name,rating.ratings,rating.review,`staff_registration`.`first_name`  as sname,`staff_registration`.`middle_name`,`staff_registration`.`last_name` FROM rating JOIN student_registration ON rating.student_id=student_registration.login_id JOIN `staff_registration` ON `staff_registration`.`login_id`=`rating`.`staff_id` ")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)

@app.route('/publicviewrating',methods=['POST'])
def publicviewrating():
    cmd.execute("SELECT rating.* , staff_registration.first_name, staff_registration.phone_no,staff_registration.email, AVG(rating.ratings) FROM rating JOIN staff_registration ON rating.staff_id=staff_registration.login_id GROUP BY rating.staff_id ")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)

@app.route('/complaint', methods=['POST'])
def complaint():
    sffid = request.form['staffid']
    stid = request.form['stid']
    complaint = request.form['complaint_message']
    print(complaint)
    cmd.execute("INSERT INTO complaint VALUES(NULL,'"+str(stid)+"','"+str(complaint)+"' ,curdate(),'pending','"+str(sffid)+"')")
    con.commit()
    return jsonify({'task': "Success"})



@app.route('/rating', methods=['POST'])
def rating():
    sffid = request.form['staffid']
    stid = request.form['stid']
    ratings= request.form['ratings']
    review = request.form['review']
    print(ratings)
    cmd.execute("INSERT INTO rating VALUES(NULL,'"+str(stid)+"','"+str(sffid)+"','"+str(review)+"','"+str(ratings)+"' ,curdate())")
    con.commit()
    return jsonify({'task': "Success"})

@app.route('/viewfeedback', methods=['POST','GET'])
def viewfeedback():
    sid=request.form['sid']
    print(sid)
    cmd.execute("SELECT feedback.*,`staff_registration`.`first_name` FROM feedback JOIN `staff_registration` ON `feedback`.`staff_id`=`staff_registration`.`login_id` WHERE feedback.`student_id`="+str(sid)+"")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)

@app.route('/viewcomplaint', methods=['POST','GET'])
def viewcomplaint():
    sid=request.form['sid']
    print(sid)
    cmd.execute("SELECT complaint.* , student_registration.first_name ,`staff_registration`.`first_name` as sname FROM complaint JOIN student_registration ON complaint.student_id=student_registration.login_id JOIN `staff_registration` ON `staff_registration`.`login_id`=`complaint`.`staff_id`")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)

@app.route('/feedback', methods=['POST'])
def feedback():
    sffid=request.form['staffid']
    stid=request.form['sid']
    feedback=request.form['feedback']
    cmd.execute("INSERT INTO feedback VALUES(NULL,"+str(stid)+","+str(sffid)+", '"+feedback+"',curdate(),'pending') ")
    con.commit()
    return jsonify({'task':"Success"})

@app.route('/feeds',methods=['POST'])
def feeds():
    sffid=request.form['staffid']
    print(sffid,"sssss")
    fnp = datetime.now().strftime("%Y%m%d%H%M%S") + ".jpg"
    photos=request.files['files']
    print(photos)
    photos.save("static/feeds/" + fnp)
    descri=request.form['des']
    print(descri)
    cmd.execute("INSERT INTO feeds VALUES(NULL,'"+str(sffid)+"','"+fnp+"',curdate(),'"+descri+"')")
    con.commit()
    return jsonify({'task':"Success"})

@app.route('/materials', methods=['POST'])
def materials():
    des=request.form['des']
    photos=request.files['files']
    sid=request.form['staffid']
    print(photos)
    fnv = secure_filename(photos.filename)
    photos.save("static/material/" + fnv)
    cmd.execute("INSERT INTO materials VALUES(NULL,'" + str(fnv) + "','" + str(des) +"', curdate(),'"+str(sid)+"')")
    con.commit()
    return jsonify({'task': "Success "})

@app.route('/viewmaterials', methods=['post','get'])
def viewmaterials():
    cmd.execute("select `materials`.*,`staff_registration`.`first_name` from `staff_registration` join `materials` on `materials`.`staff_id`=`staff_registration`.`login_id`")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)



@app.route('/viewfeeds',methods=['post'])
def viewfeeds():
    cmd.execute("SELECT `staff_registration`.`first_name`,`staff_registration`.`middle_name`,`staff_registration`.`last_name`,`feeds`.* FROM `staff_registration` JOIN `feeds` ON `staff_registration`.`login_id`=`feeds`.`staff_id`")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)

@app.route('/viewstaff',methods=['post','get'])
def viewstaff():
    cmd.execute("select * from staff_registration")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(json_data)
    return jsonify(json_data)





@app.route('/viewstudent', methods=['post','get'])
def viewstudent():
    cmd.execute("select * from student_registration where login_id in (select login_id from login where type='student')")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)



@app.route('/viewstudent2', methods=['post','get'])
def viewstudent2():
    cmd.execute("select * from student_registration where login_id in (select login_id from login where type='pending')")
    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)







@app.route('/chat' ,methods=['POST'])
def chat():
    frmid = request.form['frmid']
    print(frmid)
    recid = request.form['recid']
    print(recid)
    mess = request.form['mess']
    cmd.execute("INSERT INTO chat VALUES(NULL,'" + str(frmid) + "','" + str(recid) + "','" + str(mess) +"' ,curdate(),'pending')")
    con.commit()
    return ('success')

@app.route('/viewchat' ,methods=['POST'])
def viewchat():
    uid = request.form['uid']
    print(uid)
    fid = request.form['fid']
    print(fid)
    cmd.execute("select * from chat where (from_id='" + str(uid) + "' and reciever_id='" + str(fid) + "') or (from_id='" + str(fid) + "' and reciever_id='" + str(uid) + "') order by date asc")

    row_headers = [x[0] for x in cmd.description]
    results = cmd.fetchall()
    json_data = []
    for result in results:
        json_data.append(dict(zip(row_headers, result)))
    con.commit()
    print(results, json_data)
    return jsonify(json_data)








#
#
#
#
##@app.route('/viewwork')
#def viewwork():
 #   cmd.execute("select * from works ")
  #  row_headers = [x[0] for x in cmd.description]
   # results = cmd.fetchall()
    #json_data = []
    #for result in results:
     #   json_data.append(dict(zip(row_headers, result)))
    #con.commit()
    #print(results, json_data)
    #return jsonify(json_data)
#
# # @app.route('/viewmessage')
# # def viewmessage():
# #     id=request.arg
# # s.get('id')
# #     session['myid']=id
# #     dta =(cmd.execute("select * from message where to_id='"+id+"' "))
# #     row_headers = [x[0] for x in cmd.description]
# #     results = cmd.fetchall()
# #     json_data = []
# #     for result in results:
# #         json_data.append(dict(zip(row_headers, result)))
# #     con.commit()
# #     print(results, json_data)
# #     return jsonify(json_data)
# @app.route('/viewcomplaint',methods=['post'])
# def viewcomplaint():
#     id=request.form['uid']
#     # session['myid']=id
#     dta =(cmd.execute("select * from complaints where from_id='"+str(id)+"' "))
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#
# @app.route('/replymsg',methods=['post'])
# def replymsg():
#     session['toid']=request.args.get('to_id')
#     msgid=request.args.get('frmid')
#     msg=request.args.get('msg')
#     dta=(cmd.execute("select * from message where id='"+msgid+"'"))
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#
# # @app.route('/replyclick')
# # def replyclick():
# #     fid=session['myid']
# #     toid=session['toid']
# #     msg = request.args.get('msg')
# #     cmd.execute("insert into message values(NULL,,'"+fid+"','"+toid+"',curdate(),'"+msg+"')")
# #     return jsonify({'task', "success"})
#
#
#
# @app.route('/complaints',methods=['post'])
# def addcomplaint():
#     try:
#         complaint=request.form['com']
#         user_id=request.form['lid']
#         # print("insert into complaints values(NULL,'"+str(user_id)+"','"+str(complaint)+"','pending',curdate())")
#         cmd.execute("insert into complaints values(NULL,'"+user_id+"','"+complaint+"','pending',curdate())")
#         con.commit()
#         print("okkkkkk")
#         return jsonify({'task': "success"})
#     except Exception as e:
#         print(str(e))
#         return jsonify({'task': "Faild"})
#
# @app.route('/addcustomplan',methods=['post'])
# def addcustomplan():
#     try:
#         pname=request.form['pname']
#         area=request.form['area']
#         rooms=request.form['rooms']
#         stories=request.form['stories']
#         desc=request.form['desc']
#         archname=request.form['archname']
#         print(archname,"arch")
#         userid=request.form['lid']
#         print("insert into customized_plan values(NULL,'"+str(pname)+"','"+str(userid)+"','"+str(area)+"','"+str(rooms)+"','"+str(stories)+"','"+str(archname)+"','"+str(desc)+"','pending')")
#         cmd.execute("insert into customized_plan values(NULL,'"+str(pname)+"','"+str(userid)+"','"+str(area)+"','"+str(rooms)+"','"+str(stories)+"','"+str(archname)+"','"+str(desc)+"','pending')")
#         con.commit()
#         print("okkkkkk")
#         return jsonify({'task': "success"})
#
#     except Exception as e:
#         print(str(e))
#         return jsonify({'task': "Faild"})
#
# @app.route('/addcustomplans',methods=['post'])
# def addcustomplans():
#      try:
#          dta =cmd.execute("select id,architectname from architect")
#          row_headers = [x[0] for x in cmd.description]
#          results = cmd.fetchall()
#          json_data = []
#          for result in results:
#              json_data.append(dict(zip(row_headers, result)))
#          con.commit()
#          print(results, json_data)
#          return jsonify(json_data)
#
#      except Exception as e:
#          print(str(e))
#          return jsonify({'task': "Faild"})
#
# @app.route('/names',methods=['post'])
# def names():
#     try:
#
#                 dta = cmd.execute("select id,architectname from architect")
#                 row_headers = [x[0] for x in cmd.description]
#                 results = cmd.fetchall()
#                 print(results,"pppp")
#                 json_data = []
#                 for result in results:
#                     json_data.append(dict(zip(row_headers, result)))
#                 con.commit()
#                 print(results, json_data)
#                 return jsonify(json_data)
#
#                 # elif(type=="Exteriordesigner"):
#             #     dta = cmd.execute("select id,designer_name from exteriordesigner")
#             #     row_headers = [x[0] for x in cmd.description]
#             #     results = cmd.fetchall()
#             #     json_data = []
#             #     for result in results:
#             #         json_data.append(dict(zip(row_headers, result)))
#             #     con.commit()
#             #     print(results, json_data)
#             #
#             # elif (type == "Worker"):
#             #     dta = cmd.execute("select id,workername from worker")
#             #     row_headers = [x[0] for x in cmd.description]
#             #     results = cmd.fetchall()
#             #     json_data = []
#             #     for result in results:
#             #         json_data.append(dict(zip(row_headers, result)))
#             #     con.commit()
#             #     print(results, json_data)
#
#     except Exception as ex:
#             print(str(ex))
#             return jsonify({'task': "Faild"})
#
# @app.route('/replyclick',methods=['post'])
# def replyclick():
#     fid=request.form['from_id']
#     toid = request.form['toid']
#     msg = request.form['msg']
#     cmd.execute("insert into message values(NULL,'"+str(fid)+"','"+str(toid)+"',curdate(),'"+str(msg)+"')")
#     con.commit()
#     return jsonify({'task': "success"})
#
# @app.route('/viewchat',methods=['post'])
# def viewchat():
#     fid = request.form['from_id']
#     toid = request.form['toid']
#     dta=cmd.execute("select * from message where from_id='"+fid+"' and to_id='"+toid+"' or from_id='"+toid+"' and to_id='"+fid+"'")
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#
# @app.route('/viewplans',methods=['post'])
# def viewplans():
#     dta = (cmd.execute("select * from plan "))
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#
# @app.route('/profile',methods=['post'])
# def profile():
#     id=request.form['lid']
#     print(id)
#     (cmd.execute("select * from user where id='"+str(id)+"'"))
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#
# @app.route('/updateprof',methods=['post'])
# def updateprof():
#     try:
#         id = request.form['lid']
#         nam = request.form['name']
#         age = request.form['age']
#         pho = request.form['phno']
#         email = request.form['eid']
#         cmd.execute("update user set name='"+nam+"',age='"+age+"',phone_number='"+pho+"',email_id='"+email+"' where id='"+id+"' ")
#         con.commit()
#         print("okkkkkk")
#         return jsonify({'task': "success"})
#     except Exception as ee:
#         print(str(ee))
#         return jsonify({'task': "Faild"})
#
# # booking details for payment
# @app.route('/bookingdet',methods=['post'])
# def bookingdet():
#     try:
#             type=request.form['type']
#             uid=request.form['lid']
#             # did=request.form['dsid']
#             print(type)
#             # if(type=="plan"):
#             cmd.execute("select booking.id as bid,plan.plan_name,plan.price,plan.id from booking,plan where booking.design_id=plan.id and booking.user_id='"+str(uid)+"' and booking.status='approved' ")
#             row_headers = [x[0] for x in cmd.description]
#             results = cmd.fetchall()
#             print(results,"pppp")
#             json_data = []
#             for result in results:
#                 json_data.append(dict(zip(row_headers, result)))
#             con.commit()
#             print(results, json_data)
#             return jsonify(json_data)
#
#             #
#             # elif(type=="exteriordesign"):
#             #     cmd.execute("select booking.id as bid,exterior_design.design_name,exterior_design.price,exterior_design.id from booking,exterior_design where booking.design_id=exterior_design.id and booking.user_id='"+str(uid)+"' and booking.status='approved'")
#             #     row_headers = [x[0] for x in cmd.description]
#             #     results = cmd.fetchall()
#             #     json_data = []
#             #     for result in results:
#             #         json_data.append(dict(zip(row_headers, result)))
#             #     con.commit()
#             #     print(results, json_data)
#             #
#             # else:
#             #     cmd.execute("select booking.id as bid,works.name_of_work,works.price,works.id from booking,works where booking.design_id=works.id and booking.user_id='"+str(uid)+"' and booking.status='approved'")
#             #     row_headers = [x[0] for x in cmd.description]
#             #     results = cmd.fetchall()
#             #     json_data = []
#             #     for result in results:
#             #         json_data.append(dict(zip(row_headers, result)))
#             #     con.commit()
#             #     print(results, json_data)
#
#     except Exception as ex:
#             print(str(ex))
#             return jsonify({'task': "Faild"})
# @app.route('/pay',methods=['post'])
# def pay():
#      try:
#          ifsc=request.form['ifs']
#          accno=request.form['accno']
#          lid = request.form['lid']
#          desid = request.form['desid']
#          print(desid)
#          amt=request.form['amt']
#          print(amt)
#          bname = request.form['bnam']
#          print("select amount from bank where bankname='"+bname+"' and  and ifsc='"+ifsc+"' and `accountno`='"+accno+"'")
#          cmd.execute("select amount from bank where bankname='"+bname+"' and ifsc='"+ifsc+"' and `accountno`='"+accno+"' and uid='"+str(lid)+"'")
#          s=cmd.fetchone()
#          print(s[0])
#          if s is None:
#              print("invalid details")
#              return jsonify({'task': "Faild"})
#          elif(str(s[0])<str(amt)):
#              print("insufficient balance")
#              return jsonify({'task': "insufficient balance"})
#          else:
#              res = float(s[0])-float(amt)
#              print("result", res)
#              cmd.execute("update bank set amount='"+str(res)+"' where bankname='"+str(bname)+"' and ifsc='"+str(ifsc)+"'")
#              cmd.execute("update booking set status='paid' where user_id='"+str(lid)+"' and design_id='"+str(desid)+"'")
#              con.commit()
#              print("+++++ success" )
#              return jsonify({'task': "success"})
#
#      except Exception as ex:
#          print(str(ex)+"failed")
#          return jsonify({'task': "Faild"})
#
# @app.route('/rating',methods=['post'])
# def rating():
#             try:
#                 rating=request.form['rate']
#                 uid=request.form['lid']
#                 desid=request.form['desid']
#                 print(desid)
#                 print(rating)
#                 print(uid)
#                 d=desid.replace('[','').replace(']','')
#                 print(d)
#                 cmd.execute("insert into rating values(NULL,'"+str(uid)+"','"+str(d)+"','"+rating+"')")
#                 con.commit()
#                 print("+++++ success")
#                 return jsonify({'task': "success"})
#             except Exception as ex:
#                 print(str(ex) + "failed")
#                 return jsonify({'task': "failed"})
#
# # @app.route('/workbooking',methods=['get'])
# # def workbooking():
# #     try:
# #
#
# #plan ext design booking
# @app.route('/addbooking',methods=['post'])
# def addbooking():
#     uid=request.form['lid']
#
#     # cmd.execute("select id from plan where id='"+did+"'")
#     # cmd.execute("select id from exterior_design where id="+did+"")
#     # c=cmd.fetchone()
#     did=request.form['planid']
#     cmd.execute("insert into booking values(NULL,'"+str(uid)+"','"+str(did)+"',curdate(),'pending')")
#     con.commit()
#     return jsonify({'task': "success"})
#
# @app.route('/areachoose',methods=['post'])
# def areachoose():
#     area=request.form['area']
#     cmd.execute("select * from plan where area<'"+str(area)+"' and status='approved'")
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#
# @app.route('/viewext',methods=['post'])
# def viewext():
#     dta = (cmd.execute("select * from exterior_design"))
#     row_headers = [x[0] for x in cmd.description]
#     results = cmd.fetchall()
#     json_data = []
#     for result in results:
#         json_data.append(dict(zip(row_headers, result)))
#     con.commit()
#     print(results, json_data)
#     return jsonify(json_data)
#



if __name__=="__main__":
    app.run(host='0.0.0.0',port=5000)

